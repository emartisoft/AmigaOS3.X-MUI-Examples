#ifndef REV_H
#define REV_H

#define PROJECTNAME         "TMEP"
#define COPYRIGHT           "Copyright � 2016"
#define FULLVERSION_STRING  "v1.0 (23.10.2016)"

#endif