AmigaOS3.X-MUI-Examples
=======================
MUI based C Project Examples for Amiga OS 3.X

Requirements to compile examples
================================
AmigaOS3.X or Classic Workbench 3.X 
http://classicwb.abime.net

MagicUserInterface 3.8, user files
https://muidev.de/download/MUI%203.8%20-%20AmigaOS3-m68k/mui38usr.lha
http://aminet.net/util/libs/mui38usr.lha

MagicUserInterface 3.8, developer files
https://muidev.de/download/MUI%203.8%20-%20AmigaOS3-m68k/mui38dev.lha
http://aminet.net/dev/mui/mui38dev.lha

GCC based Amiga Development Environment
http://m68k.aminet.net/package/dev/gcc/ADE
http://aminet.net/dev/gcc/ADE.zip


How to Setup MUI and GCC on Amiga
=================================
Setup_MUI_and_GCC_on_AmigaOS3.X.pdf (Turkish)
https://github.com/emartisoft/AmigaOS3.X-MUI-Examples/blob/master/Setup_MUI_and_GCC_on_AmigaOS3.X.pdf

Coded by emarti, Murat �zdemir Oct 23, 2016
email: dtemarti@gmail.com 

Enjoy it!